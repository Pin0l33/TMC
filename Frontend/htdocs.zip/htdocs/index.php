<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teknical may cry</title>
    <link rel="icon" type="image/png" href="Logo TmC bg.png">
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>
<body>
    <header>
        <?php include 'nav.php'; ?>
    </header>
    <main>
        <section class="hero">
            <div class="hero-content">
                <h2>Teknical May Cry</h2>
                <p>
                    Visita a la tecnica y diviertete en la instalación
                </p>
                <a href="descarga.php" class="btn">
                    DESCARGAR
                </a>
            </div>
        </section>
    </main>
    <footer>
        <p>
            © 2026 Teknical May Cry
        </p>
    </footer>
</body>
</html>
